The problem with this implementation:

Errors found:
Error in test 4: get_next_line(5: "read_error.txt"): Segmentation fault!
     in sigsegv utils.c:53:1
     in get_next_line get_next_line.c:129:19
     in test_gnl_func file_utils.c:40:8
     in main tester.c:193:2

Error in test 4: get_next_line(5: "read_error.txt"): Segmentation fault!
     in sigsegv utils.c:53:1
     in get_next_line get_next_line.c:129:19
     in test_gnl_func file_utils.c:40:8
     in main tester.c:193:2

Error in test 4: get_next_line(5: "limits.txt"): Segmentation fault!
     in sigsegv utils.c:53:1
     in get_next_line get_next_line.c:129:19
     in test_gnl_func_limits file_utils.c:73:8
     in test_limit tester.c:84:7
     in main tester.c:235:3

Error in test 4: get_next_line(5: "read_error.txt"): Segmentation fault!
     in sigsegv utils.c:53:1
     in get_next_line get_next_line.c:129:19
     in test_gnl_func file_utils.c:40:8
     in main tester.c:193:2
